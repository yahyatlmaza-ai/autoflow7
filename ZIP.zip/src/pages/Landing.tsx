import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Package, Truck, BarChart3, Shield, Zap, RefreshCw, Users,
  CheckCircle, ChevronDown, ArrowRight, Star, Play,
  ShoppingBag, MapPin, MessageCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../lib/i18n';
import ScrollToTop from '../components/ui/ScrollToTop';
import PlatformLogo from '../components/PlatformLogo';

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.7, ease: 'easeOut' as const } }),
};

const stats = [
  { key: 'hero_stat1', value: '2M+' },
  { key: 'hero_stat2', value: '5K+' },
  { key: 'hero_stat3', value: '12+' },
  { key: 'hero_stat4', value: '99.9%' },
];

const features = [
  { icon: Truck, key1: 'feat1_title', key2: 'feat1_desc', color: 'from-blue-500 to-cyan-500' },
  { icon: Zap, key1: 'feat2_title', key2: 'feat2_desc', color: 'from-amber-500 to-orange-500' },
  { icon: MapPin, key1: 'feat3_title', key2: 'feat3_desc', color: 'from-green-500 to-emerald-500' },
  { icon: Package, key1: 'feat4_title', key2: 'feat4_desc', color: 'from-purple-500 to-violet-500' },
  { icon: BarChart3, key1: 'feat5_title', key2: 'feat5_desc', color: 'from-pink-500 to-rose-500' },
  { icon: ShoppingBag, key1: 'feat6_title', key2: 'feat6_desc', color: 'from-indigo-500 to-blue-500' },
  { icon: Users, key1: 'feat7_title', key2: 'feat7_desc', color: 'from-teal-500 to-cyan-500' },
  { icon: RefreshCw, key1: 'feat8_title', key2: 'feat8_desc', color: 'from-red-500 to-orange-500' },
];

const steps = [
  { num: '01', key1: 'how1_title', key2: 'how1_desc' },
  { num: '02', key1: 'how2_title', key2: 'how2_desc' },
  { num: '03', key1: 'how3_title', key2: 'how3_desc' },
  { num: '04', key1: 'how4_title', key2: 'how4_desc' },
];

const algerianCarriers = [
  { name: 'Yalidine', logo: '📦' },
  { name: 'ZR Express', logo: '🚚' },
  { name: 'Noest', logo: '⚡' },
  { name: 'Amana', logo: '🏷️' },
  { name: 'EMS Algeria', logo: '📬' },
];

const intlCarriers = [
  { name: 'DHL', logo: '🟡' },
  { name: 'FedEx', logo: '🟣' },
  { name: 'UPS', logo: '🟤' },
  { name: 'Aramex', logo: '🔵' },
];

const platforms = [
  { name: 'Shopify', logo: '🛝' },
  { name: 'WooCommerce', logo: '🛎️' },
  { name: 'Magento', logo: '🔶' },
  { name: 'OpenCart', logo: '🛒' },
  { name: 'Custom API', logo: '🔧' },
];

const plans = [
  {
    key: 'pricing_basic',
    price: { DZD: '3,900', USD: '29', EUR: '27' },
    features: ['500 orders/month', '2 stores', '5 carriers', 'Basic analytics', 'Email support'],
    popular: false,
  },
  {
    key: 'pricing_pro',
    price: { DZD: '9,900', USD: '74', EUR: '68' },
    features: ['5,000 orders/month', '10 stores', 'All carriers', 'Advanced analytics', 'Priority support', 'COD management', 'Bulk operations'],
    popular: true,
  },
  {
    key: 'pricing_ent',
    price: null,
    features: ['Unlimited orders', 'Unlimited stores', 'All carriers', 'Custom analytics', 'Dedicated support', 'Custom integrations', 'SLA guarantee', 'White label'],
    popular: false,
  },
];

const testimonials = [
  {
    name: 'Karim Boudiaf',
    role: 'E-commerce Owner, Algiers',
    text: 'Octomatic transformed my logistics. I went from manually processing 50 orders a day to automating 500+. The Yalidine and ZR Express integrations are flawless.',
    rating: 5,
    avatar: 'KB',
  },
  {
    name: 'Sarah Meziane',
    role: 'Founder, Fashion Store',
    text: 'The COD management feature alone saved me hours every week. Real-time tracking and the analytics dashboard give me complete visibility over my business.',
    rating: 5,
    avatar: 'SM',
  },
  {
    name: 'Ahmed Taleb',
    role: 'Multi-store Merchant, Oran',
    text: 'Managing 3 stores and 2 warehouses was a nightmare before Octomatic. Now everything is in one place. The Arabic RTL support is perfect.',
    rating: 5,
    avatar: 'AT',
  },
  {
    name: 'Lina Hadjadj',
    role: 'Shopify Seller, Constantine',
    text: 'The Shopify integration was up in minutes. Orders flow automatically and labels are generated instantly. Best investment for my business.',
    rating: 5,
    avatar: 'LH',
  },
];

const faqs = [
  {
    q: 'How does the 10-day free trial work?',
    a: 'Sign up with your email, verify your account, and get instant access to all Professional plan features for 10 days. No credit card required.',
  },
  {
    q: 'Which Algerian carriers are supported?',
    a: 'We support Yalidine, ZR Express, Noest, Amana, and EMS Algeria, with more being added regularly. International carriers include DHL, FedEx, UPS, and Aramex.',
  },
  {
    q: 'Can I connect multiple e-commerce stores?',
    a: 'Yes! You can connect Shopify, WooCommerce, Magento, OpenCart, and custom APIs. Professional plan supports up to 10 stores.',
  },
  {
    q: 'Is Arabic RTL supported?',
    a: 'Absolutely. The platform fully supports Arabic with RTL layout, French, and English without any interface changes.',
  },
  {
    q: 'How is COD managed?',
    a: 'Our COD module tracks all cash-on-delivery orders, reconciles payments from carriers, and provides detailed reports and automated follow-ups.',
  },
  {
    q: 'What currencies are supported?',
    a: 'Algerian Dinar (DZD) is the default currency. USD and EUR are also supported with automatic conversion.',
  },
];

export default function Landing() {
  const { lang, currency, platformSettings } = useApp();
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const platformName = platformSettings?.platform_name || 'Octomatic';

  return (
    <div className="bg-white dark:bg-gray-950 text-gray-900 dark:text-white overflow-hidden">
      <ScrollToTop />
      {/* Hero */}
      <section className="relative min-h-screen flex items-center pt-20">
        {/* Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-violet-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-indigo-500/5 to-violet-500/5 rounded-full blur-3xl" />
          {/* Grid */}
          <div
            className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
            style={{
              backgroundImage: 'linear-gradient(rgba(99,102,241,1) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,1) 1px, transparent 1px)',
              backgroundSize: '60px 60px',
            }}
          />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-5xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={0}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 dark:bg-indigo-900/30 border border-indigo-200 dark:border-indigo-800/50 rounded-full text-indigo-700 dark:text-indigo-300 text-sm font-semibold mb-8"
            >
              <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
              {t(lang, 'hero_badge')}
            </motion.div>

            <motion.h1
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={1}
              className="text-5xl sm:text-6xl lg:text-8xl font-black tracking-tight leading-none mb-6"
            >
              <span className="text-gray-900 dark:text-white">{t(lang, 'hero_title')}</span>
              <br />
              <span className="bg-gradient-to-r from-indigo-500 via-violet-500 to-purple-500 bg-clip-text text-transparent">
                {t(lang, 'hero_title2')}
              </span>
            </motion.h1>

            <motion.p
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={2}
              className="text-lg sm:text-xl text-gray-500 dark:text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed"
            >
              {t(lang, 'hero_sub')}
            </motion.p>

            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={3}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
            >
              <button
                onClick={() => navigate('/signup')}
                className="group flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-bold text-lg rounded-2xl shadow-2xl shadow-indigo-500/30 hover:shadow-indigo-500/50 transition-all duration-300 hover:-translate-y-0.5"
              >
                {t(lang, 'hero_cta1')}
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => navigate('/demo')}
                className="group flex items-center gap-3 px-8 py-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white font-bold text-lg rounded-2xl hover:border-indigo-400 dark:hover:border-indigo-500 transition-all duration-300 hover:-translate-y-0.5 shadow-lg"
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center">
                  <Play className="w-3 h-3 text-indigo-600 fill-indigo-600" />
                </div>
                {t(lang, 'hero_cta2')}
              </button>
            </motion.div>

            {/* Stats */}
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={4}
              className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto"
            >
              {stats.map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400 font-medium">{t(lang, stat.key)}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, y: 80, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.6, duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="mt-20 relative"
          >
            <div className="relative mx-auto max-w-5xl">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-violet-500/20 blur-3xl rounded-3xl" />
              <div className="relative bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-2xl overflow-hidden">
                {/* Mock browser bar */}
                <div className="flex items-center gap-2 px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-950">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-amber-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                  <div className="flex-1 mx-4 px-4 py-1.5 bg-white dark:bg-gray-900 rounded-lg text-xs text-gray-400 border border-gray-200 dark:border-gray-700">
                    app.shipdz.dz/dashboard
                  </div>
                </div>
                {/* Dashboard content */}
                <div className="p-6 bg-gray-50 dark:bg-gray-950">
                  <div className="grid grid-cols-4 gap-4 mb-6">
                    {[
                      { label: 'Total Orders', value: '2,847', change: '+12%', color: 'from-indigo-500 to-violet-500' },
                      { label: 'Revenue', value: '4.2M DZD', change: '+8%', color: 'from-green-500 to-emerald-500' },
                      { label: 'Delivered', value: '2,541', change: '+15%', color: 'from-blue-500 to-cyan-500' },
                      { label: 'Pending', value: '156', change: '-3%', color: 'from-amber-500 to-orange-500' },
                    ].map((card, i) => (
                      <div key={i} className="bg-white dark:bg-gray-900 rounded-2xl p-4 border border-gray-200 dark:border-gray-800">
                        <div className={`text-xs font-semibold bg-gradient-to-r ${card.color} bg-clip-text text-transparent mb-1`}>{card.label}</div>
                        <div className="text-xl font-black text-gray-900 dark:text-white">{card.value}</div>
                        <div className={`text-xs font-medium mt-1 ${card.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>{card.change} this week</div>
                      </div>
                    ))}
                  </div>
                  {/* Chart placeholder */}
                  <div className="bg-white dark:bg-gray-900 rounded-2xl p-4 border border-gray-200 dark:border-gray-800 mb-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm font-bold text-gray-900 dark:text-white">Order Volume</span>
                      <span className="text-xs text-gray-400">Last 14 days</span>
                    </div>
                    <div className="flex items-end gap-1 h-20">
                      {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 88, 72, 100].map((h, i) => (
                        <div
                          key={i}
                          className="flex-1 rounded-t-sm bg-gradient-to-t from-indigo-600 to-violet-500 opacity-80"
                          style={{ height: `${h}%` }}
                        />
                      ))}
                    </div>
                  </div>
                  {/* Orders list */}
                  <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
                    {[
                      { id: '#ORD-2847', customer: 'Karim B.', carrier: 'Yalidine', status: 'Delivered', amount: '4,500 DZD' },
                      { id: '#ORD-2846', customer: 'Sarah M.', carrier: 'ZR Express', status: 'Shipped', amount: '8,200 DZD' },
                      { id: '#ORD-2845', customer: 'Ahmed T.', carrier: 'Noest', status: 'Processing', amount: '2,800 DZD' },
                    ].map((order, i) => (
                      <div key={i} className={`flex items-center justify-between px-4 py-3 text-xs ${i < 2 ? 'border-b border-gray-100 dark:border-gray-800' : ''}`}>
                        <span className="font-mono text-gray-500 dark:text-gray-400">{order.id}</span>
                        <span className="font-medium text-gray-900 dark:text-white">{order.customer}</span>
                        <span className="text-gray-500 dark:text-gray-400">{order.carrier}</span>
                        <span className={`px-2 py-0.5 rounded-full font-semibold ${
                          order.status === 'Delivered' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                          order.status === 'Shipped' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                          'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                        }`}>{order.status}</span>
                        <span className="font-bold text-gray-900 dark:text-white">{order.amount}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-32 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-6">
              {t(lang, 'feat_title')}
            </h2>
            <p className="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">{t(lang, 'feat_sub')}</p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feat, i) => (
              <motion.div
                key={i}
                variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.05}
                className="group bg-white dark:bg-gray-900 rounded-3xl p-6 border border-gray-200 dark:border-gray-800 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-xl hover:shadow-indigo-500/10 transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${feat.color} flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <feat.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">{t(lang, feat.key1)}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{t(lang, feat.key2)}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-20">
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-6">{t(lang, 'how_title')}</h2>
            <p className="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">{t(lang, 'how_sub')}</p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.1}
                className="relative text-center"
              >
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-[calc(50%+40px)] right-0 h-px bg-gradient-to-r from-indigo-300 to-transparent dark:from-indigo-800" />
                )}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-indigo-500/30">
                  <span className="text-white font-black text-lg">{step.num}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{t(lang, step.key1)}</h3>
                <p className="text-gray-500 dark:text-gray-400 leading-relaxed">{t(lang, step.key2)}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Integrations */}
      <section id="integrations" className="py-32 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-black mb-6">Shipping Partners & Integrations</h2>
            <p className="text-xl text-gray-500 dark:text-gray-400">All your carriers and platforms in one place</p>
          </motion.div>
          <div className="space-y-10">
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 text-center">Algerian Carriers</h3>
              <div className="flex flex-wrap justify-center gap-4">
                {algerianCarriers.map((c, i) => (
                  <motion.div
                    key={i}
                    variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.05}
                    className="flex items-center gap-3 px-6 py-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-lg transition-all duration-300"
                  >
                    <span className="text-2xl">{c.logo}</span>
                    <span className="font-bold text-gray-900 dark:text-white">{c.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 text-center">International Carriers</h3>
              <div className="flex flex-wrap justify-center gap-4">
                {intlCarriers.map((c, i) => (
                  <motion.div
                    key={i}
                    variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.05}
                    className="flex items-center gap-3 px-6 py-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-lg transition-all duration-300"
                  >
                    <span className="text-2xl">{c.logo}</span>
                    <span className="font-bold text-gray-900 dark:text-white">{c.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 text-center">E-Commerce Platforms</h3>
              <div className="flex flex-wrap justify-center gap-4">
                {platforms.map((c, i) => (
                  <motion.div
                    key={i}
                    variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.05}
                    className="flex items-center gap-3 px-6 py-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-lg transition-all duration-300"
                  >
                    <span className="text-2xl">{c.logo}</span>
                    <span className="font-bold text-gray-900 dark:text-white">{c.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-6">{t(lang, 'pricing_title')}</h2>
            <p className="text-xl text-gray-500 dark:text-gray-400">{t(lang, 'pricing_sub')}</p>
          </motion.div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, i) => (
              <motion.div
                key={i}
                variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.1}
                className={`relative rounded-3xl p-8 border ${
                  plan.popular
                    ? 'bg-gradient-to-b from-indigo-600 to-violet-700 border-transparent text-white shadow-2xl shadow-indigo-500/30 scale-105'
                    : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-amber-400 text-gray-900 text-xs font-black rounded-full">
                    {t(lang, 'pricing_popular')}
                  </div>
                )}
                <h3 className={`text-xl font-black mb-4 ${plan.popular ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                  {t(lang, plan.key)}
                </h3>
                {plan.price ? (
                  <div className="mb-6">
                    <span className={`text-5xl font-black ${plan.popular ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                      {currency === 'DZD' ? plan.price.DZD : currency === 'USD' ? plan.price.USD : plan.price.EUR}
                    </span>
                    <span className={`text-sm ml-1 ${plan.popular ? 'text-indigo-200' : 'text-gray-500'}`}>
                      {currency} {t(lang, 'pricing_mo')}
                    </span>
                  </div>
                ) : (
                  <div className="mb-6">
                    <span className={`text-3xl font-black ${plan.popular ? 'text-white' : 'text-gray-900 dark:text-white'}`}>Custom</span>
                  </div>
                )}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feat, j) => (
                    <li key={j} className={`flex items-center gap-3 text-sm ${
                      plan.popular ? 'text-indigo-100' : 'text-gray-600 dark:text-gray-400'
                    }`}>
                      <CheckCircle className={`w-4 h-4 flex-shrink-0 ${plan.popular ? 'text-indigo-200' : 'text-indigo-500'}`} />
                      {feat}
                    </li>
                  ))}
                </ul>
                {plan.price ? (
                  <button
                    onClick={() => navigate('/signup')}
                    className={`w-full py-3 rounded-2xl font-bold text-sm transition-all duration-200 ${
                      plan.popular
                        ? 'bg-white text-indigo-700 hover:bg-indigo-50'
                        : 'bg-indigo-600 text-white hover:bg-indigo-700'
                    }`}
                  >
                    {t(lang, 'pricing_trial')}
                  </button>
                ) : (
                  <a
                    href="https://wa.me/213794157508"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 rounded-2xl font-bold text-sm border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-200 flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    {t(lang, 'pricing_contact')}
                  </a>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-black mb-6">{t(lang, 'test_title')}</h2>
            <p className="text-xl text-gray-500 dark:text-gray-400">{t(lang, 'test_sub')}</p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {testimonials.map((test, i) => (
              <motion.div
                key={i}
                variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.1}
                className="bg-white dark:bg-gray-900 rounded-3xl p-8 border border-gray-200 dark:border-gray-800 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: test.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">"{test.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white font-bold text-sm">
                    {test.avatar}
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 dark:text-white text-sm">{test.name}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{test.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-32">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-black mb-6">{t(lang, 'faq_title')}</h2>
            <p className="text-xl text-gray-500 dark:text-gray-400">{t(lang, 'faq_sub')}</p>
          </motion.div>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <motion.div
                key={i}
                variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i * 0.05}
                className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                >
                  <span className="font-bold text-gray-900 dark:text-white pr-4">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform duration-300 ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-5 text-gray-600 dark:text-gray-400 leading-relaxed">{faq.a}</div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}
            className="relative bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 rounded-3xl p-12 sm:p-16 overflow-hidden"
          >
            <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 30% 50%, white 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
            <div className="relative">
              <h2 className="text-3xl sm:text-5xl font-black text-white mb-6">Ready to Automate Your Logistics?</h2>
              <p className="text-indigo-200 text-lg mb-8">Join 5,000+ merchants already growing with Octomatic. Start your free 10-day trial today.</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => navigate('/signup')}
                  className="px-8 py-4 bg-white text-indigo-700 font-bold rounded-2xl hover:bg-indigo-50 transition-colors shadow-xl"
                >
                  Start Free Trial
                </button>
                <a
                  href="https://wa.me/213794157508"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-8 py-4 border-2 border-white/30 text-white font-bold rounded-2xl hover:bg-white/10 transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  Contact on WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-400 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
            <div className="lg:col-span-2">
              <div className="mb-4">
                <PlatformLogo size="md" variant="full" forceTheme="dark" />
              </div>
              <p className="text-sm leading-relaxed mb-6">{t(lang, 'footer_desc')}</p>
              <a
                href="https://wa.me/213794157508"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded-xl transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                {t(lang, 'footer_whatsapp')}
              </a>
            </div>
            {[
              {
                title: t(lang, 'footer_product'),
                links: ['Features', 'Pricing', 'Integrations', 'API Docs', 'Changelog'],
              },
              {
                title: t(lang, 'footer_company'),
                links: ['About', 'Blog', 'Careers', 'Press', 'Partners'],
              },
              {
                title: t(lang, 'footer_support'),
                links: ['Help Center', 'Documentation', 'Status', 'Contact', 'Community'],
              },
            ].map((col, i) => (
              <div key={i}>
                <h4 className="text-white font-bold mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-sm hover:text-indigo-400 transition-colors">{link}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm">{t(lang, 'footer_rights')}</p>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="w-4 h-4 text-green-400" />
              <span>SOC 2 Compliant · GDPR Ready · 99.9% Uptime</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
